// Add popup HTML to the document
// document.body.insertAdjacentHTML('beforeend', `
//     <div class="popup-overlay" id="successPopup">
//         <div class="success-popup">
//             <i class="fas fa-check-circle"></i>
//             <h3>Registration Successful!</h3>
//             <p>Your profile has been created successfully and is pending verification. Our team will review your details shortly.</p>
//             <button class="popup-close-btn" onclick="closePopup()">
//                 Got it!
//             </button>
//         </div>
//     </div>
// `);

// Handle dietitian registration
document.getElementById('dietitianForm').addEventListener('submit', function(event) {
    event.preventDefault();

    // Collect form data
    const dietitianData = {
        id: Date.now(),
        name: document.getElementById('name').value,
        qualification: document.getElementById('qualification').value,
        specialty: document.getElementById('specialty').value,
        experience: document.getElementById('experience').value,
        availability: document.getElementById('availability').value,
        consultationFee: document.getElementById('consultationFee').value,
        description: document.getElementById('description').value,
        rating: 0, // Default rating for new dietitians
        verified: false, // New dietitians start unverified
        dateJoined: new Date().toISOString()
    };

    try {
        // Validate data
        const errors = DietitianManager.validateDietitianData(dietitianData);
        if (errors.length > 0) {
            throw new Error(errors.join('\n'));
        }

        // Save dietitian data
        const savedDietitian = DietitianManager.addDietitian(dietitianData);

        // Show success message
        showNotification('Registration successful! Awaiting verification.', 'success');
        
        // Clear form
        this.reset();

        // Optional: Redirect after delay
        setTimeout(() => {
            window.location.href = '../index.html';
        }, 3000);

    } catch (error) {
        console.error('Registration error:', error);
        showNotification(error.message, 'error');
    }
});

function showSuccessPopup() {
    const popup = document.createElement('div');
    popup.className = 'popup-overlay';
    popup.innerHTML = `
        <div class="success-popup">
            <i class="fas fa-check-circle"></i>
            <h3>Registration Successful!</h3>
            <p>You have been registered as a dietitian.</p>
        </div>
    `;
    document.body.appendChild(popup);
    setTimeout(() => {
        popup.remove();
        window.location.href = '../index.html';
    }, 3000); // Show for 3 seconds
}

function closePopup() {
    const popup = document.getElementById('successPopup');
    popup.classList.remove('active');
}

// Show notification function
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    
    const icon = document.createElement('i');
    icon.className = type === 'success' ? 'fas fa-check-circle' : 'fas fa-exclamation-circle';
    
    const text = document.createElement('span');
    text.textContent = message;
    
    notification.appendChild(icon);
    notification.appendChild(text);
    
    document.body.appendChild(notification);
    
    // Remove notification after 5 seconds
    setTimeout(() => {
        notification.classList.add('fade-out');
        setTimeout(() => notification.remove(), 300);
    }, 5000);
}

// Add form validation
function validateForm() {
    const form = document.getElementById('dietitianForm');
    const inputs = form.querySelectorAll('input, select, textarea');
    
    inputs.forEach(input => {
        input.addEventListener('input', function() {
            validateInput(this);
        });
        
        input.addEventListener('blur', function() {
            validateInput(this);
        });
    });
}

function validateInput(input) {
    const value = input.value.trim();
    const errorElement = input.parentElement.querySelector('.error-message') || 
                        document.createElement('div');
    
    errorElement.className = 'error-message';
    
    let isValid = true;
    let errorMessage = '';

    switch(input.id) {
        case 'name':
            if (value.length < 3) {
                isValid = false;
                errorMessage = 'Name must be at least 3 characters long';
            }
            break;
            
        case 'qualification':
            if (!value) {
                isValid = false;
                errorMessage = 'Qualification is required';
            }
            break;
            
        case 'experience':
            if (isNaN(value) || value < 0) {
                isValid = false;
                errorMessage = 'Please enter valid years of experience';
            }
            break;
            
        case 'consultationFee':
            if (isNaN(value) || value <= 0) {
                isValid = false;
                errorMessage = 'Please enter valid consultation fee';
            }
            break;
            
        case 'description':
            if (value.length < 50) {
                isValid = false;
                errorMessage = 'Description must be at least 50 characters long';
            }
            break;
    }

    if (!isValid) {
        errorElement.textContent = errorMessage;
        if (!input.parentElement.querySelector('.error-message')) {
            input.parentElement.appendChild(errorElement);
        }
        input.classList.add('invalid');
    } else {
        if (input.parentElement.querySelector('.error-message')) {
            input.parentElement.querySelector('.error-message').remove();
        }
        input.classList.remove('invalid');
    }

    return isValid;
}

// Initialize form validation
document.addEventListener('DOMContentLoaded', validateForm); 

// Live Preview Functionality
document.addEventListener('DOMContentLoaded', function() {
    // Initialize form validation
    validateForm();
    
    // Setup live preview
    setupLivePreview();
    
    // Setup image upload
    setupImageUpload();
});

function setupLivePreview() {
    const formInputs = document.querySelectorAll('input, select, textarea');
    formInputs.forEach(input => {
        input.addEventListener('input', updatePreview);
    });
}

function updatePreview() {
    // Update name
    const name = document.getElementById('name').value || 'Your Name';
    document.getElementById('previewName').textContent = name;
    
    // Update specialty
    const specialty = document.getElementById('specialty').value || 'Specialty';
    document.getElementById('previewSpecialty').textContent = specialty;
    
    // Update qualification
    const qualification = document.getElementById('qualification').value || 'Qualification';
    document.getElementById('previewQualification').textContent = qualification;
    
    // Update experience
    const experience = document.getElementById('experience').value || '0';
    document.getElementById('previewExperience').textContent = `${experience} years`;
    
    // Update description
    const description = document.getElementById('description').value || 'Your professional description will appear here...';
    document.getElementById('previewDescription').textContent = description;
    
    // Update consultation fee
    const fee = document.getElementById('consultationFee').value || '0';
    document.getElementById('previewFee').textContent = `₹${fee} per session`;
    
    // Update availability
    const availability = document.getElementById('availability').value || 'Not specified';
    document.getElementById('previewAvailability').textContent = availability;
    
    // Update location
    const location = document.getElementById('location').value || 'Location';
    document.getElementById('previewLocation').textContent = location;
}

function setupImageUpload() {
    const imageInput = document.getElementById('profileImageInput');
    imageInput.addEventListener('change', function(event) {
        const file = event.target.files[0];
        if (file && file.type.startsWith('image/')) {
            const reader = new FileReader();
            reader.onload = function(e) {
                document.getElementById('previewProfileImage').src = e.target.result;
                // Store image data in localStorage or your database
                localStorage.setItem('dietitianProfileImage', e.target.result);
            };
            reader.readAsDataURL(file);
        }
    });
}

// Form Submission
document.getElementById('dietitianForm').addEventListener('submit', async function(event) {
    event.preventDefault();
    
    try {
        // Collect form data
        const formData = {
            id: Date.now(),
            name: document.getElementById('name').value,
            email: document.getElementById('email').value,
            phone: document.getElementById('phone').value,
            location: document.getElementById('location').value,
            qualification: document.getElementById('qualification').value,
            specialty: document.getElementById('specialty').value,
            experience: document.getElementById('experience').value,
            license: document.getElementById('license').value,
            consultationFee: document.getElementById('consultationFee').value,
            availability: document.getElementById('availability').value,
            description: document.getElementById('description').value,
            profileImage: localStorage.getItem('dietitianProfileImage'),
            verified: false,
            rating: 0,
            dateJoined: new Date().toISOString()
        };

        // Validate data
        const errors = validateDietitianData(formData);
        if (errors.length > 0) {
            throw new Error(errors.join('\n'));
        }

        // Save to database
        const savedDietitian = await DietitianManager.addDietitian(formData);
        
        // Show success message
        showSuccessMessage();
        
        // Redirect to dashboard after delay
        setTimeout(() => {
            window.location.href = 'dashboard.html';
        }, 3000);

    } catch (error) {
        showErrorMessage(error.message);
    }
});

function validateDietitianData(data) {
    const errors = [];
    
    if (!data.name || data.name.length < 3) {
        errors.push('Name must be at least 3 characters long');
    }
    
    if (!data.email || !isValidEmail(data.email)) {
        errors.push('Please enter a valid email address');
    }
    
    if (!data.phone || !isValidPhone(data.phone)) {
        errors.push('Please enter a valid phone number');
    }
    
    if (!data.qualification) {
        errors.push('Qualification is required');
    }
    
    if (!data.specialty) {
        errors.push('Please select your specialty');
    }
    
    if (!data.experience || data.experience < 0) {
        errors.push('Please enter valid years of experience');
    }
    
    if (!data.consultationFee || data.consultationFee <= 0) {
        errors.push('Please enter a valid consultation fee');
    }
    
    if (!data.description || data.description.length < 50) {
        errors.push('Professional summary must be at least 50 characters long');
    }
    
    return errors;
}

function isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function isValidPhone(phone) {
    return /^\d{10}$/.test(phone);
}

function showSuccessMessage() {
    const notification = document.createElement('div');
    notification.className = 'notification success';
    notification.innerHTML = `
        <i class="fas fa-check-circle"></i>
        <span>Registration successful! You have been registered as a dietitian.</span>
    `;
    document.body.appendChild(notification);
    setTimeout(() => {
        notification.remove();
    }, 3000); // Show for 3 seconds
}

function showErrorMessage(message) {
    const notification = document.createElement('div');
    notification.className = 'notification error';
    notification.innerHTML = `
        <i class="fas fa-exclamation-circle"></i>
        <span>${message}</span>
    `;
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.remove();
    }, 5000);
} 